package Part02;

public class Product {
	
private int proCode, proQtyAvailable;
private String proMake, proModel;
private double proPrice;
private boolean proDiscontinued;

/**
 * Constructor for Product
 * @param proCode Primary key used to identify the product from within an array list
 * @param proQtyAvailable Integer storing the number of the product available
 * @param proMake
 * @param proModel
 * @param proPrice double containing the product price
 * @param proDiscontinued boolean to store whether or not the product is in production
 */
public Product(int proCode, int proQtyAvailable, String proMake, String proModel, double proPrice, boolean proDiscontinued) 
{
	this.proCode = proCode;
	this.proQtyAvailable = proQtyAvailable;
	this.proMake = proMake;
	this.proModel = proModel;
	this.proPrice = proPrice;
	this.proDiscontinued = proDiscontinued;
}

	public int getProCode() 
	{
		return proCode;
	}
	
	public void setProCode(int proCode) 
	{
		this.proCode = proCode;
	}
	
	public int getProQtyAvailable() 
	{
		return proQtyAvailable;
	}
	
	public void setProQtyAvailable(int proQtyAvailable) 
	{
		this.proQtyAvailable = proQtyAvailable;
	}
	
	public String getProMake()
	{
		return proMake;
	}
	
	public void setProMake(String proMake) 
	{
		this.proMake = proMake;
	}
	
	public String getProModel() 
	{
		return proModel;
	}
	
	public void setProModel(String proModel) 
	{
		this.proModel = proModel;
	}
	
	public double getProPrice()
	{
		return proPrice;
	}
	
	public void setProPrice(double proPrice)
	{
		this.proPrice = proPrice;
	}
	
	public boolean isProDiscontinued() 
	{
		return proDiscontinued;
	}
	
	public void setProDiscontinued(boolean proDiscontinued)
	{
		this.proDiscontinued = proDiscontinued;
	}
	
	/**
	 * Method to return the full product details in string format
	 * @return the full product details in string format
	 */
	public String getProDetails() 
	{
		String returnString = "Product Code: " + proCode + "\nProduct Make: " + proMake + "\nProduct Model: " + proModel + "\nProduct Price: �" + proPrice + "\nQuantity Available: " + proQtyAvailable + "\nProduct in Production?: " + yesOrNo(proDiscontinued);
		return returnString;
	}
	
	//method to display yes instead of true, or no instead of false
	private String yesOrNo(boolean proDiscontinued2) {
		String returnString;
		if(proDiscontinued) {returnString = "Yes";}
		else {returnString = "No";}
		return returnString;
	}
	
	
	
	}
