package Part02;

import java.util.Scanner;

/**
 * 
 * @author Peter Gilfedder
 * 40204792
 * Class to validate entered values in my 2017 Semester 1 Programming Assignment
 *
 */
public class Validation {

	/**
	 * Method to validate whether an input is an integer, and then calls a method to check whether it is within a specific range
	 * if it is
	 * @param min, minimum value for the range of the entered integer
	 * @param max, maximum value for the range of the entered integer
	 * @param sc, carried through Scanner from the Class it is called from
	 * @return Returns the inputed value from the user
	 */
	public static int checkInt(int min, int max, Scanner sc) 
	{
		boolean bool = false;
		int input = 0;
			do 
			{
				try {
					input = sc.nextInt();
					bool = checkInt(min, max, input, sc);
				}//Try catch method to make sure that the users input is an integer if it throws an exception at any point instead runs the catch code
				catch(Exception e) 
				{
					System.err.println("the value entered is not an integer please re-enter your value");
					sc.nextLine();
				}
			}
			while(!bool);
	sc.nextLine();	
	return input;
	}
		
	/**
	 * Method to validate that the entered integer, is within the range selected, if not returns false
	 * @param min minimum value to be valid
	 * @param max maximum value to be valid
	 * @param input value being tested
	 * @param sc Scanner as carried from previous method or Class
	 * @return returns a boolean value, true if valid, false if outside the range
	 */

	private static boolean checkInt(int min, int max, int input, Scanner sc) {
		boolean bool = false;
			if(input <= max && input >= min) 
			{
				bool = true;
			}	
			else 
			{
				System.err.println("The value you have entered is outside the accepted range of: "+ min + " to "+ max +", please try again");
				sc.nextLine();
			}
		return bool;
	}
	
	/**
	 * Method to validate whether an input is a number, and then calls a method to check whether it is within a specific range
	 * if it is
	 * @param min, minimum value for the range of the entered double
	 * @param max, maximum value for the range of the entered double
	 * @param sc, carried through Scanner from the Class it is called from
	 * @return Returns the inputed value from the user
	 */
	
	public static double checkDouble(double min, double max, Scanner sc) 
	{
		boolean bool = false;
		double input = 0;
			do 
			{
				try {
					input = sc.nextDouble();
					bool = checkDouble(min, max, input, sc);
				}//Try catch method to make sure that the users input is an double if it throws an exception at any point instead runs the catch code
				catch(Exception e) 
				{
					System.err.println("the value entered is not a number please re-enter your value");
					sc.nextLine();
				}
			}
			while(!bool);
	sc.nextLine();	
	return input;
	}
		
	/**
	 * Method to validate that the entered double, is within the range selected, if not returns false
	 * @param min minimum value to be valid
	 * @param max maximum value to be valid
	 * @param input value being tested
	 * @param sc Scanner as carried from previous method or Class
	 * @return returns a boolean value, true if valid, false if outside the range
	 */

	private static boolean checkDouble(double min, double max, double input, Scanner sc) {
		boolean bool = false;
			if(input <= max && input >= min) 
			{
				bool = true;
			}	
			else 
			{
				System.err.println("The value you have entered is outside the accepted range of: "+ min + " to "+ max +", please try again");
				sc.nextLine();
			}
		return bool;
	}
	
	/**
	 * This is a method to convert user inputed yes's and no's to boolean true and false values
	 * @param in this is the scanner input stream from the method that this method is called from
	 * @return returns the boolean value which is calculated
	 */
	public static boolean enteredStringToBool(Scanner in) 
	{
		boolean Return = false;
		boolean loop = true;
		
		do {
			String input = in.nextLine();
			if(input.toLowerCase().equals("yes")) 
			{
				Return = true;
				loop = false;
			}
			else if(input.toLowerCase().equals("no")) 
			{
				Return = false;
				loop = false;
			}
			else 
			{
				System.err.println("Please enter either yes or no, no other input will be accepted");		
				loop = true;
			}
		}while(loop);
		return Return;
	}
	
	
	/**
	 * Method to validate that the entered postcode is in a standard post code format using hasNext statements
	 * @param sc input stream from the location that this is called from
	 * @return returns the validated inputed value
	 */
	public static String checkPostCode(Scanner sc) 
	{
		boolean loop = true;
		String postCode = "";
		do 
		{
			if(sc.hasNext("[A-Za-z]{1,2}[0-9][0-9][0-9]{A-Za-z}{2}") || sc.hasNext("[A-Za-z]{1,2}[0-9][0-9]{A-Za-z}{2}")) //if statement to check that the value entered is in the apropriate form of LLNNLL or LLNNNLL
			{
				postCode = sc.next();
				loop = false;
			}
			else 
			{
				System.out.println("The entered post code is not in the correct format of \nLetterLetterNumberNumberNumberLetterLetter \nor\nLetterLetterNumberNumberLetterLetter\nplease enter a new value(remember no spaces!)");
			}
		}while(loop);
		return postCode;
	}
	
	/**
	 * Method to validate that the next inputed value is not just blank or a space
	 * @param sc input stream from the location that this is called from
	 * @return returns the validated inputed value
	 */
	public static String checkString(Scanner sc) 
	{
		boolean loop = true;
		String input = "";
		do 
		{
			input = sc.nextLine();
			if(input.equals("") || input.equals(" ")) 
			{
				System.out.println("You have not enterd a value please re-enter your value");
			}
			else 
			{
				loop = false;
			}
		}while(loop);				
		return input;
	}
	
	
	
}

