package Part02;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Scanner;

import Part02.Validation;

public class Main {

	public static ArrayList<Supplier> suppliers = new ArrayList<Supplier>(); 	//Creating the array list to hold the instances of Supplier
	public static Scanner in = new Scanner(System.in);	//Opening the Scanner

	public static void main(String[] args) 
	{
		createTestSuppliersAndProducts();//method to create a bunch of basic suppliers and products to decrease testing time
		mainMenu(); // calls the main menu method
		System.exit(0); //ends the program after the mainMenu method ends
	}
	//method to create a bunch of basic suppliers and products to decrease testing time
	public static void createTestSuppliersAndProducts() 
	{
		Product pro1 = new Product(100, 600, "iPhone", "6s", 540.00, false);
		Product pro2 = new Product(101, 700, "iPhone", "7", 740.00, false);
		Product pro3 = new Product(102, 800, "iPhone", "8", 940.00, false);
		Product pro4 = new Product(100, 100, "Acer Spin", "1 1.11", 200.00, false);
		Product pro5 = new Product(101, 100, "Acer Spin", "2 3.11", 300.00, false);
		Product pro6 = new Product(102, 100, "Acer Spin", "5 5.11", 400.00, false);
		Product pro7 = new Product(100, 100000, "Jelly Baby", "Orange", 0.01, false);
		Product pro8 = new Product(101, 100000, "Jelly Baby", "Strawberry", 0.02, false);
		Product pro9 = new Product(102, 100000, "Jelly Baby", "Rasberry", 0.03, false);
		
		ArrayList<Product> proList1 = new ArrayList<Product>();
		ArrayList<Product> proList2 = new ArrayList<Product>();
		ArrayList<Product> proList3 = new ArrayList<Product>();
		
		proList1.add(pro1);
		proList1.add(pro2);
		proList1.add(pro3);
		proList2.add(pro4);
		proList2.add(pro5);
		proList2.add(pro6);
		proList3.add(pro7);
		proList3.add(pro8);
		proList3.add(pro9);
	
		suppliers.add(new Supplier("Apple", (new Address("Great Victoria Street","BT16FB","Belfast","Northern Ireland",31)), 100, proList1, SupRegion.UNITED_KINGDOM));
		suppliers.add(new Supplier("Acer", (new Address("Great Victoria Street","BT16FB","Belfast","Northern Ireland",32)), 101, proList2, SupRegion.UNITED_KINGDOM));
		suppliers.add(new Supplier("Haribo", (new Address("Great Victoria Street","BT16FB","Belfast","Northern Ireland",33)), 102, proList3, SupRegion.UNITED_KINGDOM));
	}

	/**
	 * Main menu method which displays the options available to the user and prompts them to choose one
	 * validates that the users entry is both an integer and then that it is a value on the list
	 * the entered value is validated using the Validation class
	 */
	private static void mainMenu() 
	{
		boolean loop = true;
		do 
		{
			int choice; // local variable which stores the users choice of option
			System.out.println("Please select an option by number:");
			System.out.println("1: Print All Products");
			System.out.println("2: Add New Supplier");
			System.out.println("3: Add New Product");
			System.out.println("4: Edit Existing Supplier");
			System.out.println("5: Delete Existing Supplier");
			System.out.println("6: Edit Existing Product");
			System.out.println("7: Delete Existing Product");
			System.out.println("8: Buy Products");
			System.out.println("9: Exit");
			//if statement to validate the users entry and take them to their appropriate method
			choice = Validation.checkInt(1,9,in);
			switch(choice)
			{
			case 1: printAll(); break;
			case 2: addSupplier(); break;
			case 3: addProduct(); break;
			case 4: editSupplierDetails();break;
			case 5: deleteSupplier(); break;
			case 6: editProduct(); break;
			case 7: deleteProduct(); break;
			case 8: shoppingBasket(); break;
			case 9: loop = false; break;
			}
		}while(loop);
	}

	/**
	 * Print all suppliers and products method
	 * goes through each supplier in the array list and prints their details, and then their products and its details
	 */
	private static void printAll() 
	{
		//enhanced for loop to print supplier details
		for(Supplier supplier: suppliers) 
		{
			System.out.println("---Supplier Details---\n");
			System.out.println(supplier.getSupplierDetails());
			System.out.println("\n---" + supplier.getSupName() + "'s Product Details---\n");
			for(Product product: supplier.getProducts()) //enhanced for loop to print the product details
			{
				System.out.println(product.getProDetails());
				System.out.println();
			}
		}
		System.out.println();
	}

	/**
	 * Method to prompt the user for information about the supplier
	 * then save this information as an instance of Supplier 
	 * then add this to the array list suppliers
	 * each entered value is validated using the Validation class
	 */
	private static void addSupplier() 
	{
		System.out.println("-------Adding a New Supplier-------\nPlease input the name of the new supplier you wish to add: ");
		String supName = Validation.checkString(in);
		Address supAddress = getAddress(); //calls get address method, to create an instance of Address for use in this instance of supplier
		System.out.println("Please enter the Region from which the supplier originates: ");
		SupRegions();
		SupRegion supRegion = SupRegion.values()[Validation.checkInt(1, 3, in)-1]; 
		int supCode = 100 + suppliers.size(); //the supplier code is saved as the users position in the array plus 100, this allows for suppliers to be searched for based on their supplier code as it is now a primary key
		ArrayList<Product> products = new ArrayList<Product>();
		//Asks the user if they would like to add products to the supplier then validates their reply and either adds products or continues with the program
		System.out.println("Would you like to add any products to this supplier?(Yes/No): ");
		boolean add = Validation.enteredStringToBool(in);
		if(add) 
		{
			products = addProductToSupplier();
		}
		else 	
		{
			System.out.println("No products have been added to " + supName);
		}
		//creating an instance of supplier and adding it to the array list suppliers
		Supplier temp = new Supplier(supName, supAddress, supCode, products, supRegion);
		suppliers.add(temp);
	}

	/**
	 * Method to display all available enum choices for SupRegion beside their position in the enum for user selection
	 */
	private static void SupRegions() 
	{
		//method to display all Enum values along with their position to allow for user selection of the suppliers region
		int numOfRegions = EnumSet.allOf(SupRegion.class).size();
		int index = 1;
		while (index <= numOfRegions) 
		{    
			System.out.println(index + ": " + SupRegion.values()[index-1].getEnumAsString());
			index++;     
		}  
	}

	/**
	 * Method to ask the user for input about the address of the supplier, then creates an instance of address and returns it
	 * @return returns the new address object
	 * each entered value is validated using the Validation class
	 */
	private static Address getAddress() 
	{
		System.out.println("Please enter the street number of the suppliers address: ");
		int bldNum = Validation.checkInt(1, 1000000, in);
		System.out.println("Please enter the street of the suppliers address: ");
		String bldStreet = Validation.checkString(in);
		System.out.println("Please enter the Post Code of the suppliers address: ");
		String bldPCode = Validation.checkString(in);
		System.out.println("Please enter the Town of the suppliers address: ");
		String bldTown = Validation.checkString(in);
		System.out.println("Please enter the country of the suppliers address: ");
		String bldCountry = Validation.checkString(in);
		Address temp = new Address(bldStreet, bldPCode, bldTown, bldCountry, bldNum);
		return temp;
	}

	/**
	 * method to add suppliers to the newly created supplier, asks user for number of products they wish to add, then adds each one they create to an array list
	 * @return returns the array list created with all the products for the supplier in it
	 */
	public static ArrayList<Product> addProductToSupplier() 
	{
		System.out.println("How many Products would you like to add to this Suppliers account?(max 10 per iteration): ");
		int num = Validation.checkInt(1, 10, in);
		ArrayList<Product> products = new ArrayList<Product>();
		for(int i = 0; i < num; i++) 
		{
			System.out.println("Please enter the make of the product: ");
			String proMake = Validation.checkString(in);
			System.out.println("Please enter the model of the product: ");
			String proModel = Validation.checkString(in);
			System.out.println("Please enter the number of the product available (Max Stock Space = 1,000,000): ");
			int proQtyAvailable = Validation.checkInt(1, 1000000, in);
			System.out.println("Please enter the price of the product: �");
			double proPrice = Validation.checkDouble(0.00, 1000000.00, in);
			System.out.println("Is this product currently being produced? (Yes/No): ");
			boolean proDiscontinued = Validation.enteredStringToBool(in);
			//product code is created similar to the supplier code, adding 100 to its position in the array list
			int proCode = 100 + i;
			Product tempPro = new Product(proCode, proQtyAvailable, proMake, proModel, proPrice, proDiscontinued);
			products.add(tempPro);
		}
		return products;
	}

	/**
	 * Method to add a product to an already created supplier, 
	 * asks for the supplier code
	 * asks how many products to add to this supplier
	 * then prompts the user to enter the info for each of these products
	 * then adds these to the array list for the suppliers products
	 */
	public static void addProduct() 
	{
		if(suppliers.size() > 0) {//Method only runs if there has been at least one supplier created
			System.out.println("Please enter the supplier code of the supplier of this product: ");
			displayAllSuppliers();
			int code = Validation.checkInt(100, (100 + (suppliers.size() - 1)), in);
			//supplier is selected by their supplier code which is equal to its position in the array list plus 100, so the users inputed code -100 is equal to its position
			Supplier tempSupp = suppliers.get(code-100);

			System.out.println("How many Products would you like to add to this Suppliers account? (max 10 per iteration): ");
			int num = Validation.checkInt(1, 10, in);
			for(int i = 0; i < num; i++) 
			{
				System.out.println("Please enter the make of the product: ");
				String proMake = Validation.checkString(in);
				System.out.println("Please enter the model of the product: ");
				String proModel = Validation.checkString(in);
				System.out.println("Please enter the number of the product available (Max Stock Space = 1,000,000): ");
				int proQtyAvailable = Validation.checkInt(1, 1000000, in);
				System.out.println("Please enter the price of the product: �");
				double proPrice = Validation.checkDouble(0.00, 1000000.00, in);
				System.out.println("Is this product currently being produced? (Yes/No): ");
				boolean proDiscontinued = Validation.enteredStringToBool(in);
				//as in this method the supplier is being added to directly,
				//the suppliers arraylist of products' size plus 100 is used to generate the product code,
				//as the size is one more then the final position in the array 
				//therefore, the new one is added at the position equal to its size before it was added
				int proCode = 100 + tempSupp.getProducts().size();
				Product tempPro = new Product(proCode, proQtyAvailable, proMake, proModel, proPrice, proDiscontinued);
				tempSupp.addProducts(tempPro);
			}
		}
		else {System.out.println("There is currently no suppliers to add products too");
		}
	}

	/**
	 * Method to edit the selected supplier, this method is similar to my add product method to begin with, then simply lets the user select
	 * a detail to edit, then asks them for new input and changes the stored value in the object to this new value
	 */
	public static void editSupplierDetails() 
	{
		if(suppliers.size() > 0) {//Method only runs if there has been at least one supplier created
			System.out.println("Please enter the supplier code of the supplier of this product: ");
			displayAllSuppliers();
			int code = Validation.checkInt(1, (100 + (suppliers.size() - 1)), in);
			//supplier is selected by their supplier code which is equal to its position in the array list plus 100, so the users inputed code -100 is equal to its position
			Supplier tempSupp = suppliers.get(code-100);

			System.out.println("Which detail would you like to edit?(Choose a number from the list below: ");
			System.out.println("1: Supplier name");
			System.out.println("2: Supplier Address");
			System.out.println("3: Supplier Region");

			int choice; // local variable which stores the users choice of option
			//if statement to validate the users entry and edit the appropriate detail
			choice = Validation.checkInt(1,3,in);
			switch(choice)
			{
			case 1: 
				System.out.println("Please enter the suppliers new name:");
				tempSupp.setSupName(in.nextLine());
				break;
			case 2: tempSupp.setSupAddress(getAddress()); 
			break;
			case 3: 
				System.out.println("Please enter the new Region from which the supplier originates: ");
				SupRegions();
				tempSupp.setSupRegion(SupRegion.values()[Validation.checkInt(1, 3, in)-1]); 
				break;
			}	
		}
		else {System.out.println("There are currently no suppliers to edit");
		}
	}

	/**
	 * Method for selecting a supplier then deleting that instance of supplier
	 */
	private static void deleteSupplier() {
		if(suppliers.size() > 0) { //Method only runs if there has been at least one supplier created
			System.out.println("Please enter the supplier code of the supplier of this product: ");
			displayAllSuppliers();
			int code = Validation.checkInt(1,(100 + (suppliers.size() - 1)), in);
			//supplier is selected by their supplier code which is equal to its position in the array list plus 100, so the users inputed code -100 is equal to its position
			Supplier tempSupp = suppliers.get(code-100);
			System.out.println("Are you sure you wish to delete this supplier?(Yes/No)");
			System.out.println(tempSupp.getSupplierDetails());
			boolean choice = Validation.enteredStringToBool(in);
			if(choice) 
			{
				System.out.println("Supplier " + suppliers.get(code-100).getSupCode() + " deleted");
				editSupCodes(code-100);
				suppliers.remove(code-100);
			}
			else 
			{
				System.out.println("Deletion cancelled");
			}

		}
		else {System.out.println("There are currently no suppliers to edit");
		}
	}

	/**
	 * Method which edits the users selected product, it does this by selecting a supplier, then selecting one of their 
	 * products then the user selects a detail to edit then edits this detail to the new value they enter
	 * ends the method if there are no suppliers or no products in the supplier
	 */
	public static void editProduct() 
	{
		if(suppliers.size() > 0) {//Method only runs if there has been at least one supplier created
			System.out.println("Please enter the supplier code of the supplier of this product: ");
			displayAllSuppliers();
			int code = Validation.checkInt(100, (100 + (suppliers.size() - 1)), in); 
			//supplier is selected by their supplier code which is equal to its position in the array list plus 100, so the users inputed code -100 is equal to its position
			Supplier tempSupp = suppliers.get(code-100);
			if(tempSupp.getProducts().size() > 0) 
			{//this part of the method only runs if the user has created products for the supplier
				System.out.println("Please enter the product code of the product you wish to edit: ");
				for(Product product : tempSupp.getProducts()) 
				{
					System.out.println(product.getProDetails());
				}

				int choice = Validation.checkInt(100, (99 + tempSupp.getProducts().size()), in) - 100;

				System.out.println("Which detail would you like to edit?(Choose a number from the list below: ");
				System.out.println("1: Product Make");
				System.out.println("2: Product Model");
				System.out.println("3: Product Price");
				System.out.println("4: Product Discontinued?");
				System.out.println("5: Product Quantity");

				// local variable which stores the users choice of option
				//switch statement to validate the users entry and edit the appropriate detail
				int choice2 = Validation.checkInt(1,5,in);
				switch(choice2)
				{
				case 1: 
					System.out.println("Please enter the Products new make:");
					tempSupp.getProducts().get(choice).setProMake(in.nextLine());
					break;
				case 2: 
					System.out.println("Please enter the Products new model:");
					tempSupp.getProducts().get(choice).setProModel(in.nextLine());
					break;
				case 3: 
					System.out.println("Please enter the Products new Price:");
					tempSupp.getProducts().get(choice).setProPrice(Validation.checkDouble(0.01, 1000000.00, in));
					break;
				case 4:
					System.out.println("Is this product currently being produced? (Yes/No): ");
					tempSupp.getProducts().get(choice).setProDiscontinued(Validation.enteredStringToBool(in));
					break;
				case 5: 
					System.out.println("Please enter the new quantity of the product:");
					tempSupp.getProducts().get(choice).setProQtyAvailable(Validation.checkInt(1, 1000000, in));
					break;
				}	
			}else {System.out.println("There are currently no Products to edit");}
		}
		else {System.out.println("There are currently no suppliers to edit");}
	}

	/**
	 * Method to delete a product, lets the user select a supplier then a product from that supplier to remove
	 */
	public static void deleteProduct() 
	{
		if(suppliers.size() > 0) {//Method only runs if there has been at least one supplier created
			System.out.println("Please enter the supplier code of the supplier of this product: ");
			displayAllSuppliers();
			int code = Validation.checkInt(100, (100 + (suppliers.size() - 1)), in); 
			//supplier is selected by their supplier code which is equal to its position in the array list plus 100, so the users inputed code -100 is equal to its position
			Supplier tempSupp = suppliers.get(code-100);
			if(tempSupp.getProducts().size() > 0) 
			{//this part of the method only runs if the user has created products for the supplier
				System.out.println("Please enter the product code of the product you wish to delete: ");
				for(Product product : tempSupp.getProducts()) 
				{
					System.out.println(product.getProDetails());
				}
				int choice = Validation.checkInt(100, (99 + tempSupp.getProducts().size()), in) - 100;
				System.out.println("Are you sure you wish to delete this product? (Yes/No)");
				boolean choice2 = Validation.enteredStringToBool(in);
				if(choice2) 
				{
					System.out.println(tempSupp.getProducts().get(choice).getProCode() + " has been Deleted");
					editProCodes(choice, tempSupp.getProducts());
					tempSupp.getProducts().remove(choice);
				}
				else 
				{
					System.out.println("Deletion cancelled");
				}

			}else {System.out.println("There are currently no Products to edit");}
		}
		else {System.out.println("There are currently no suppliers to edit");}
	}

	/**
	 * This method is very complex and long, i have used a lot of different methods and techniques to build it, i had to use two arrays Lists as i do not know how to use 2D array lists 
	 * aswell i have had to use a series of other methods and case switch statements
	 * however this method allows the user to both search for products, and sort all products, as well as allowing them to then add this to their "Shopping Basket" and then by these items
	 * Furthermore once an item has been selected it can also be removed once the user has added any other items they wish to add
	 * I believe this is an important method as the majority of the rest of the project is not very useful unless you can actually be supplied with products from the program
	 */
	public static void shoppingBasket() 
	{
		double totalPrice = 0; //double to store the total price of the shopping basket
		ArrayList<Product> productsSelected = new ArrayList<Product>(); //array list to store the different products added
		ArrayList<Integer> numOfProducts = new ArrayList<Integer>();// array list to store the number of each product they wish to buy, created in an array list so that if the user deletes a product then the one deleted here will not offset the positioning of the product and the number bought
		boolean ans = true; //loop variable to allow for multiple additions of products to the basket
		if(suppliers.size() > 0) 
		{//Method only runs if there has been at least one supplier created
			do 
			{
				Product temp = null; //temporary variable to store the added product
				//Options for the user to find their product
				System.out.println("The currently available search and sort options are listed below, please select an option to find a product");
				System.out.println("1: Search Options: ");
				System.out.println("2: Sort Options: ");
				System.out.println("3: Checkout: ");
				int choice1 = Validation.checkInt(1, 3, in);
				switch(choice1)
				{
				case 1:
					System.out.println("Now Select a search option");
					System.out.println("  11: Search by code\n  12: Search by Make\n  13: Search by Model\n  14: Search by Price");
					int choice2 = Validation.checkInt(11, 14, in);
					temp = search(choice2); //calls the search method which corresponds to their search choice
					productsSelected.add(temp); //adds the product to the array list
					System.out.println("How many of these products would you like to add?(max = Quantity available): "); //allows the user to add more than one and adds the number they want to buy to an arraylist in the same position but a different list
					numOfProducts.add(Validation.checkInt(1, temp.getProQtyAvailable(), in));	
					break;
				case 2:
					System.out.println("Now Select a sort option");
					System.out.println("  21: Sort by Supplier\n  22: Sort by Price(Ascending)\n  23: Sort by Price(Descending)");
					int choice3 = Validation.checkInt(21, 23, in);
					temp = sort(choice3); //calls the sort method which corresponds to their sort choice
					productsSelected.add(temp); //adds the product to the array list
					System.out.println("How many of these products would you like to add?(max = Quantity available): "); //allows the user to add more than one and adds the number they want to buy to an arraylist in the same position but a different list
					numOfProducts.add(Validation.checkInt(1, temp.getProQtyAvailable(), in));	
					break;
				case 3: ans = false; break;
				}
			}while(ans);


			for(int i = 0; i < productsSelected.size(); i++) //gets the total price of their basket	
			{
				totalPrice += (productsSelected.get(i).getProPrice() * numOfProducts.get(i));
			}

			System.out.println("The products you have selected are: ");
			int index = 1;
			for(Product product : productsSelected) 
			{
				System.out.println(index + ": " + product.getProDetails());//prints out the products they have selected
				System.out.println("You chose to buy " + numOfProducts.get(index-1) + " of these");
				index++;
			}
			System.out.printf("And the total cost of these products is: �%.2f\n" , totalPrice);
			System.out.println("Would you like to remove any products?(Yes/No): ");
			boolean delete = Validation.enteredStringToBool(in);
			if(delete) 
			{
				int num = 1;
				for(Product product : productsSelected) 
				{
					System.out.println(num + ": " + product.getProDetails());
					num++;
				}
				System.out.println("Choose a number from above to delete");
				productsSelected.remove(Validation.checkInt(1, productsSelected.size(), in)-1);
			}
			else 
			{
				System.out.println("Your shopping basket is being processed, and your purchases will be with you shortly\nThank you for shopping with us today :)");
			}
		}
		else
		{
			System.out.println("There are currently suppliers or products created in the system");
		}
	}

/**
 * method which allows the user to search for a specific product by its price, code name or model, it then adds this to a seperate array list in case there is more than 1 with this detail then allows the to choose one of these to add to their shopping basket
 * @param i this parameter is the users input into which search option they require
 * @return returns the chosen product to be added to the shopping basket
 */
	private static Product search(int i)
	{
		ArrayList<Product> AllProducts = new ArrayList<Product>(); //array list to store all products
		ArrayList<Product> searchProducts = new ArrayList<Product>(); //arraylist to store the products which have been selected due to the users inputed search data
		int selectedSearchProduct = 0; //integer to save which product from the search products array list they have selected
		for(Supplier supplier : suppliers) 
		{
			for(Product products : supplier.getProducts()) 
			{
				AllProducts.add(products);
			}
		}
		switch(i) 
		{
		case 11://this case allows the user to search by product code by letting them input a value and displaying which products match this value
			do{
				System.out.println("What is the product code you would like to search for?: ");
				int tempCode = Validation.checkInt(100, 200, in); //gets product code
				for(Product product : AllProducts) {
					if(tempCode == product.getProCode()) 
					{
						searchProducts.add(product);//adds any products with the selected code to the arraylist
					}
				}
				if(searchProducts.size() == 0) 
				{
					System.out.println("No Products met the value you entered, please retry"); // if the user enters an unused code allows them to re enter the code
				}
				else 
				{
					int index = 0;//int to show position in search products array
					System.out.println("From the list below please choose a product by number");
					for(Product search : searchProducts) 
					{
						index++;
						System.out.println(index + ": " + search.getProDetails());
					}
					selectedSearchProduct = Validation.checkInt(1, searchProducts.size(), in) - 1;//stores the location of the users selected product
				}
			}while(searchProducts.size() == 0);
		break;
		case 12: //this case allows the user to search by make by letting them input a value and displaying which products match this value
			 do{
				System.out.println("What is the make you would like to search for?: ");
				String tempMake = Validation.checkString(in);
				for(Product product : AllProducts) {
					if(tempMake.equals(product.getProMake()))
					{
						searchProducts.add(product);
					}
				}
				if(searchProducts.size() == 0) 
				{
					System.out.println("No Products met the value you entered, please retry");
				}
				else 
				{
					int index = 0;//int to show position in search products array
					System.out.println("From the list below please choose a product by number");
					for(Product search : searchProducts) 
					{
						index++;
						System.out.println(index + ": " + search.getProDetails());
					}
					selectedSearchProduct = Validation.checkInt(1, searchProducts.size(), in) - 1;
				}
			}while(searchProducts.size() == 0);
		break;
		case 13: //this case allows the user to search by model by letting them input a value and displaying which products match this value
			 do{
				System.out.println("What is the model you would like to search for?: ");
				String tempModel = Validation.checkString(in);
				for(Product product : AllProducts) {
					if(tempModel.equals(product.getProModel()))
					{
						searchProducts.add(product);
					}
				}
				if(searchProducts.size() == 0) 
				{
					System.out.println("No Products met the value you entered, please retry");
				}
				else 
				{
					int index = 0;//int to show position in search products array
					System.out.println("From the list below please choose a product by number");
					for(Product search : searchProducts) 
					{
						index++;
						System.out.println(index + ": " + search.getProDetails());
					}
					selectedSearchProduct = Validation.checkInt(1, searchProducts.size(), in) - 1;
				}
			}while(searchProducts.size() == 0);
		break;
		case 14: //this case allows the user to search by price by letting them input a value and displaying which products match this value
			do{
				System.out.println("What is the price of product you would like to search for?: ");
				double tempPrice = Validation.checkDouble(0.00, 1000000.00, in);
				for(Product product : AllProducts) {
					if(tempPrice == product.getProPrice()) 
					{
						searchProducts.add(product);
					}
				}
				if(searchProducts.size() == 0) 
				{
					System.out.println("No Products met the value you entered, please retry");
				}
				else 
				{
					int index = 0;//int to show position in search products array
					System.out.println("From the list below please choose a product by number");
					for(Product search : searchProducts) 
					{
						index++;
						System.out.println(index + ": " + search.getProDetails());
					}
					selectedSearchProduct = Validation.checkInt(1, searchProducts.size(), in) - 1;
				}
			}while(searchProducts.size() == 0);
		break;
		}
		return searchProducts.get(selectedSearchProduct);
	}

	private static Product sort(int i) 
	{
		ArrayList<Product> AllProducts = new ArrayList<Product>();
		ArrayList<Product> sortedProducts = new ArrayList<Product>();
		Product returnProduct = null;
		int selectedProduct = 0;
		for(Supplier supplier : suppliers) 
		{
			for(Product products : supplier.getProducts()) 
			{
				AllProducts.add(products);
			}
		}
		switch(i) 
		{
		case 21: 
			int proNum1 = 0; // integer to store which product is being displayed at each line
			//enhanced for loop to print supplier details
			for(Supplier supplier: suppliers) 
			{
				System.out.println("---Supplier Details---\n");
				System.out.println(supplier.getSupplierDetails());
				System.out.println("\n---" + supplier.getSupName() + "'s Product Details---\n");
				for(Product product: supplier.getProducts()) //enhanced for loop to print the product details
				{
					System.out.println(proNum1 + ": " + product.getProDetails());
					System.out.println();
					proNum1++;
				}
			}
			System.out.println("Please select a product by the number displayed before its details");
			selectedProduct = Validation.checkInt(0, AllProducts.size(), in);
			returnProduct = AllProducts.get(selectedProduct);
			break;
		case 22:
			int proNum2 = 0; // integer to store which product is being displayed at each line
			Product min = null;
				for(Product product1 : AllProducts) 
				{
					min = new Product(0,0,"","",1000001,true); //creates a basic product to reset the new minimum in every iteration
					for(Product product2 : AllProducts) 
					{
						if(product2.getProPrice() < min.getProPrice() && !sortedProducts.contains(product2)) 
						{
							min = product2;	
						}
					}
					if(product1.getProPrice() < min.getProPrice() && !sortedProducts.contains(product1)) 
					{
						min = product1;	
					}
					sortedProducts.add(min);
				}
				for(Product sort : sortedProducts) 
				{
					System.out.println(proNum2 + ": " + sort.getProDetails());
					proNum2++;
				}
				System.out.println("Please select a product by the number displayed before its details");
				selectedProduct = Validation.checkInt(0, AllProducts.size(), in);
				returnProduct = AllProducts.get(selectedProduct);
			break;
		case 23:
			int proNum3 = 0; // integer to store which product is being displayed at each line
			Product max = null;
				for(Product product1 : AllProducts) 
				{
					max = new Product(0,0,"","",0,true);//creates a basic product to reset the new maximum in every iteration
					for(Product product2 : AllProducts) 
					{
						if(product2.getProPrice() > max.getProPrice() && !sortedProducts.contains(product2)) 
						{
							max = product2;	
						}
					}
					if(product1.getProPrice() > max.getProPrice() && !sortedProducts.contains(product1)) 
					{
						min = product1;	
					}
					sortedProducts.add(max);
				}
				for(Product sort : sortedProducts) 
				{
					System.out.println(proNum3 + ": " + sort.getProDetails());
					proNum3++;
				}
				System.out.println("Please select a product by the number displayed before its details");
				selectedProduct = Validation.checkInt(0, AllProducts.size(), in);
				returnProduct = AllProducts.get(selectedProduct);
			break;
		}
		return returnProduct;
	}

	/**
	 * This method edits the remaining suppliers supplier codes so that when one is removed and the size of suppliers decreases this does not result in a duplication of a supplier number
	 * @param position, this integer dictates the position from which onwards the supplier codes must decrease by 1
	 */
	private static void editSupCodes(int position) {
		for(int i = position; i < suppliers.size(); i++) 
		{
			suppliers.get(i).setSupCode(suppliers.get(i).getSupCode() - 1);
		}
	}
	
	/**
	 * This method edits the remaining Products product codes so that when one is removed and the size of products decreases this does not result in a duplication of a product number
	 * @param position, this integer dictates the position from which onwards the Product codes must decrease by 1
	 */
	private static void editProCodes(int position, ArrayList<Product> products) {
		for(int i = position; i < products.size(); i++) 
		{
			products.get(i).setProCode(products.get(i).getProCode() - 1);
		}
	}

	/**
	 * Method to display all the suppliers with their supplier codes for the user to select one
	 * uses a for each loop, to display each suppliers details in turn
	 */
	private static void displayAllSuppliers() 
	{
		for(Supplier codes : suppliers) 
		{
			System.out.println("Supplier Code: " + codes.getSupCode() + "     Supplier Name: " + codes.getSupName());
		}	
	}
}
