package part01;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Scanner;

import Part02.Address;
import Part02.Product;
import Part02.SupRegion;
import Part02.Supplier;

public class Main {

	public static ArrayList<Supplier> suppliers = new ArrayList<Supplier>(); 	//Creating the array list to hold the instances of Supplier
	public static Scanner in = new Scanner(System.in);	//Opening the Scanner
	
	public static void main(String[] args) 
	{
		createTestSuppliersAndProducts(); //method to create a bunch of basic suppliers and products to decrease testing time
		mainMenu(); // calls the main menu method
	}
	//method to create a bunch of basic suppliers and products to decrease testing time
	public static void createTestSuppliersAndProducts() 
	{
		Product pro1 = new Product(100, 600, "iPhone", "6s", 540.00, false);
		Product pro2 = new Product(101, 700, "iPhone", "7", 740.00, false);
		Product pro3 = new Product(102, 800, "iPhone", "8", 940.00, false);
		Product pro4 = new Product(100, 100, "Acer Spin", "1 1.11", 200.00, false);
		Product pro5 = new Product(101, 100, "Acer Spin", "2 3.11", 300.00, false);
		Product pro6 = new Product(102, 100, "Acer Spin", "5 5.11", 400.00, false);
		Product pro7 = new Product(100, 100000, "Jelly Baby", "Orange", 0.01, false);
		Product pro8 = new Product(101, 100000, "Jelly Baby", "Strawberry", 0.02, false);
		Product pro9 = new Product(102, 100000, "Jelly Baby", "Rasberry", 0.03, false);
		
		ArrayList<Product> proList1 = new ArrayList<Product>();
		ArrayList<Product> proList2 = new ArrayList<Product>();
		ArrayList<Product> proList3 = new ArrayList<Product>();
		
		proList1.add(pro1);
		proList1.add(pro2);
		proList1.add(pro3);
		proList2.add(pro4);
		proList2.add(pro5);
		proList2.add(pro6);
		proList3.add(pro7);
		proList3.add(pro8);
		proList3.add(pro9);
	
		suppliers.add(new Supplier("Apple", (new Address("Great Victoria Street","BT16FB","Belfast","Northern Ireland",31)), 100, proList1, SupRegion.UNITED_KINGDOM));
		suppliers.add(new Supplier("Acer", (new Address("Great Victoria Street","BT16FB","Belfast","Northern Ireland",32)), 101, proList2, SupRegion.UNITED_KINGDOM));
		suppliers.add(new Supplier("Haribo", (new Address("Great Victoria Street","BT16FB","Belfast","Northern Ireland",33)), 102, proList3, SupRegion.UNITED_KINGDOM));
	}
	/**
	 * Main menu method which displays the options available to the user and prompts them to choose one
	 * validates that the users entry is both an integer and then that it is a value on the list
	 */
	private static void mainMenu() 
	{
		int choice; // local variable which stores the users choice of option
		System.out.println("Please select an option by number:");
		System.out.println("1: Print all products");
		System.out.println("2: Add new supplier");
		System.out.println("3: Add new product");
		System.out.println("4: Exit");
		//if statement to validate the users entry and take them to their appropriate method
		if(in.hasNextInt()) 
		{
			choice = in.nextInt();
			in.nextLine();
			switch(choice)
			{
				case 1: printAll(); break;
				case 2: addSupplier(); break;
				case 3: addProduct(); break;
				case 4: exit(); break;
				default: 
				{
					System.out.println("The value entered is not a valid option please try again");
					mainMenu();		
				} break;
			}
		}
		else 
		{
			System.out.println("The value entered is not an integer please try again.");
			mainMenu();
		}
	}

	/**
	 * Print all suppliers and products method
	 * goes through each supplier in the array list and prints their details, and then their products and its details
	 */
	private static void printAll() 
	{
		//enhanced for loop to print supplier details
		for(Supplier supplier: suppliers) 
		{
			System.out.println("---Supplier Details---\n");
			System.out.println(supplier.getSupplierDetails());
			System.out.println("\n---" + supplier.getSupName() + "'s Product Details---\n");
			for(Product product: supplier.getProducts()) //enhanced for loop to print the product details
			{
				System.out.println(product.getProDetails());
			}
		}
		System.out.println();
		mainMenu();
	}
	/**
	 * Method to prompt the user for information about the supplier
	 * then save this information as an instance of Supplier 
	 * then add this to the array list suppliers
	 */
	private static void addSupplier() 
	{
	    System.out.println("-------Adding a New Supplier-------\nPlease input the name of the new supplier you wish to add: ");
	    String supName = in.nextLine();
	    Address supAddress = getAddress();  //calls get address method, to create an instance of Address for use in this instance of supplier
	    System.out.println("Please enter the Region from which the supplier originates: ");
	    SupRegions();
	    SupRegion supRegion = SupRegion.values()[in.nextInt()-1]; 
		int supCode = 100 + suppliers.size(); //the supplier code is saved as the users position in the array plus 100, this allows for suppliers to be searched for based on their supplier code as it is now a primary key
		ArrayList<Product> products = new ArrayList<Product>();
		boolean bool = false;
		//while loop to ask if when creating the supplier they would like to create any products, if the answer is valid continues with the project
		while(!bool) 
		{
			System.out.println("Would you like to add any products to this supplier?(Yes/No): ");
			if(in.next().toLowerCase().equals("yes"))
				{
					products = addProductToSupplier();
					bool = true;
				}
			else if(in.next().toLowerCase().equals("no")) 
				{
					bool = true;
				}
		}
		//creating an instance of supplier and adding it to the array list suppliers
		Supplier temp = new Supplier(supName, supAddress, supCode, products, supRegion);
		suppliers.add(temp);
		mainMenu();
	}

	private static void SupRegions() 
	{
		//method to display all Enum values along with their position to allow for user selection of the suppliers region
		 int numOfRegions = EnumSet.allOf(SupRegion.class).size();
		 int index = 1;
		 while (index <= numOfRegions) 
		 {    
			 System.out.println(index + ": " + SupRegion.values()[index-1].getEnumAsString());
			 index++;     
		 }  
	 }
		
	/**
	 * Method to ask the user for input about the address of the supplier, then creates an instance of address and returns it
	 * @return returns the new address object
	 */
	private static Address getAddress() 
	{
		System.out.println("Please enter the street number of the suppliers address: ");
		int bldNum = in.nextInt();
		in.nextLine();
		System.out.println("Please enter the street of the suppliers address: ");
		String bldStreet = in.nextLine();
		System.out.println("Please enter the Post Code of the suppliers address: ");
		String bldPCode = in.nextLine();
		System.out.println("Please enter the Town of the suppliers address: ");
		String bldTown = in.nextLine();
		System.out.println("Please enter the country of the suppliers address: ");
		String bldCountry = in.nextLine();
		Address temp = new Address(bldStreet, bldPCode, bldTown, bldCountry, bldNum);
		return temp;
	}

	/**
	 * method to add suppliers to the newly created supplier, asks user for number of products they wish to add, then adds each one they create to an array list
	 * @return returns the array list created with all the products for the supplier in it
	 */
	public static ArrayList<Product> addProductToSupplier() 
	{
		System.out.println("How many Products would you like to add to this Suppliers account?: ");
		int num = in.nextInt();
		in.nextLine();
		ArrayList<Product> products = new ArrayList<Product>();
		for(int i = 0; i < num; i++) 
		{
			System.out.println("Please enter the make of the product: ");
			String proMake = in.next();
			System.out.println("Please enter the model of the product: ");
			String proModel = in.next();
			System.out.println("Please enter the number of the product available: ");
			int proQtyAvailable = in.nextInt();
			System.out.println("Please enter the price of the product: �");
			double proPrice = in.nextDouble();
			System.out.println("Is this product currently being produced? (Y/N): ");
			String Stock = in.next();
			boolean proDiscontinued = false;
			if(Stock.toUpperCase().equals("Y")) {proDiscontinued = true;}
			else if(Stock.toUpperCase().equals("N")){proDiscontinued = false;}
			//product code is created similar to the supplier code, adding 100 to its position in the array list
			int proCode = 100 + i;
			Product tempPro = new Product(proCode, proQtyAvailable, proMake, proModel, proPrice, proDiscontinued);
			products.add(tempPro);
		}
		return products;
	}

	/**
	 * Method to add a product to an already created supplier, 
	 * asks for the supplier code
	 * asks how many products to add to this supplier
	 * then prompts the user to enter the info for each of these products
	 * then adds these to the array list for the suppliers products
	 */
	public static void addProduct() 
	{
		if(suppliers.size() > 0) {
			System.out.println("Please enter the supplier code of the supplier of this product: ");
			displayAllSuppliers();
			int code = in.nextInt();
			//supplier is selected by their supplier code which is equal to its position in the array list plus 100, so the users inputted code -100 is equal to its position
			Supplier tempSupp = suppliers.get(code-100);
			
			System.out.println("How many Products would you like to add to this Suppliers account?: ");
			int num = in.nextInt();
			in.nextLine();
			for(int i = 0; i < num; i++) 
			{
				System.out.println("Please enter the make of the product: ");
				String proMake = in.next();
				System.out.println("Please enter the model of the product: ");
				String proModel = in.next();
				System.out.println("Please enter the number of the product available: ");
				int proQtyAvailable = in.nextInt();
				System.out.println("Please enter the price of the product: �");
				double proPrice = in.nextDouble();
				System.out.println("Is this product currently being produced? (Y/N): ");
				String Stock = in.next();
				boolean proDiscontinued = false;
				if(Stock.toUpperCase().equals("Y")) {proDiscontinued = true;}
				else if(Stock.toUpperCase().equals("N")){proDiscontinued = false;}
				//as in this method the supplier is being added to directly,
				//the suppliers arraylist of products' size plus 100 is used to generate the product code,
				//as the size is one more then the final position in the array 
				//therefore, the new one is added at the position equal to its size before it was added
				int proCode = 100 + tempSupp.getProducts().size();
				Product tempPro = new Product(proCode, proQtyAvailable, proMake, proModel, proPrice, proDiscontinued);
				tempSupp.addProducts(tempPro);
			}
		}
		else {System.out.println("There is currently no suppliers to add products too");
		}
		mainMenu();
	}
	
/**
 * Method to display all the suppliers with their supplier codes for the user to select one
 * uses a for each loop, to display each suppliers details in turn
 */
	private static void displayAllSuppliers() 
	{
		for(Supplier codes : suppliers) 
		{
			System.out.println("Supplier Code: " + codes.getSupCode() + "     Supplier Name: " + codes.getSupName());
		}	
	}

	/**
	 * Method to end the program
	 */
	private static void exit() 
	{
		System.out.println("Program Ending"); 
		System.exit(0);	
	}

}
