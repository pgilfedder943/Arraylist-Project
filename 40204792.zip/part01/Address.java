package part01;

public class Address 
{
	private String bldStreet, bldPCode, bldTown, bldCountry;
	private int bldNum;
	
	/**
	 * Address Constructor
	 * @param bldStreet 
	 * @param bldPCode
	 * @param bldTown
	 * @param bldCountry
	 * @param bldNum
	 */
	public Address(String bldStreet, String bldPCode, String bldTown, String bldCountry, int bldNum) 
		{	
			this.bldStreet = bldStreet;
			this.bldPCode = bldPCode;
			this.bldTown = bldTown;
			this.bldCountry = bldCountry;
			this.bldNum = bldNum;
		}
		
		public String getBldStreet() 
		{
			return bldStreet;
		}
		
		public void setBldStreet(String bldStreet) 
		{
			this.bldStreet = bldStreet;
		}
		
		public String getBldPCode()
		{
			return bldPCode;
		}
		
		public void setBldPCode(String bldPCode) 
		{
			this.bldPCode = bldPCode;
		}
		
		public String getBldTown()
		{
			return bldTown;
		}
		
		public void setBldTown(String bldTown)
		{
			this.bldTown = bldTown;
		}
		
		public String getBldCountry() 
		{
			return bldCountry;
		}
		
		public void setBldCountry(String bldCountry) 
		{
			this.bldCountry = bldCountry;
		}
		
		public int getBldNum() 
		{
			return bldNum;
		}
		
		public void setBldNum(int bldNum) 
		{
			this.bldNum = bldNum;
		}
		
		
		/**
		 * Method to display the full suppliers address
		 * @return returns the full suppliers address in string format
		 */
		public String getAddress() 
		{
			return ("Address Line 1: " + bldNum + " " + bldStreet + "\nPost Code: " + bldPCode + "\nTown: " + bldTown + "\nCountry: " + bldCountry);
		}
		
		
}
