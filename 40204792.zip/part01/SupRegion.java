package part01;
//Enum of the different regions the user can choose as part of the suppliers details
public enum SupRegion {
	UNITED_KINGDOM  {
		public String getEnumAsString() {
		
			return "United Kingdom";
		}
	},EUROPE  {
		public String getEnumAsString() {
		
			return "Europe";
		}
	},OUTSIDE_EU	{
		public String getEnumAsString() {
			
			return "Outside EU";
		}
	};
	public abstract String getEnumAsString();
}
	
