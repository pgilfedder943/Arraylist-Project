package part01;

import java.util.ArrayList;

public class Supplier 
{
	private String supName;
	private Address supAddress;
	private int supCode;
	private ArrayList<Product> products = new ArrayList<Product>();
	private SupRegion supRegion; 

	/**
	 * Supplier Constructor
	 * @param supName
	 * @param supAddress Object of type address containing the suppliers address
	 * @param supCode Primary key of suppliers to allow for easy identification of a specific supplier
	 * @param products Array list of the suppliers products (of type Product)
	 * @param supRegion enum SupRegion containing the users region of business
	 */
	public Supplier(String supName, Address supAddress, int supCode, ArrayList<Product> products, SupRegion supRegion) 
	{
		this.supName = supName;
		this.supAddress = supAddress;
		this.supCode = supCode;
		this.supRegion = supRegion;
		this.products = products;
	}

	public String getSupName() 
	{
		return supName;
	}

	public void setSupName(String supName)
	{
		this.supName = supName;
	}

	public Address getSupAddress() 
	{
		return supAddress;
	}

	public void setSupAddress(Address supAddress)
	{
		this.supAddress = supAddress;
	}

	public int getSupCode()
	{
		return supCode;
	}

	public void setSupCode(int supCode) 
	{
		this.supCode = supCode;
	}

	public ArrayList<Product> getProducts() 
	{
		return products;
	}

	public void setProducts(ArrayList<Product> products)
	{
		this.products = products;
	}
	
	public void addProducts(Product product) 
	{
		this.products.add(product);
	}

	public SupRegion getSupRegion() 
	{
		return supRegion;
	}

	public void setSupRegion(SupRegion supRegion)
	{
		this.supRegion = supRegion;
	}

	/**
	 * Method to display the users chosen suppliers full details returned as a string
	 * @return full detail of supplier
	 */
	public String getSupplierDetails() 
	{
		return ("Supplier Code: " + supCode + "\nSupplier Name : " + supName + "\nSupplier Region: " + supRegion.getEnumAsString() + "\n" + supAddress.getAddress());                                               
	}
}
